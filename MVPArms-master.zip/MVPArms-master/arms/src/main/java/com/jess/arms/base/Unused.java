package com.jess.arms.base;

import javax.inject.Inject;

/**
 * Created by yexiaokang on 2019/11/12.
 */
public class Unused {

    @Inject
    public Unused() {

    }
}
